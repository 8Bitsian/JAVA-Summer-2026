package Generics;

//=======================================
//        LinkedList
//=======================================
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Collections;



public class Roster2 {
    public static void main(String[] args) {
        //============================================================
        // Collections Framework ( [List], Map, Set)
        //============================================================
        System.out.println("---------------------- 01:LinkedList-add");
        LinkedList<String> list = new LinkedList<>();

        // 1. add elements
        list.add("1Emma");
        list.add("2Ben");
        list.add("3Ava");
        list.add("5Mia");
        list.add(3,"4Henry"); // inserts an element at a specific index

        //print all the elements
        for (String s : list) {
            System.out.println(s);
        }
        System.out.println("LinkedList: the input order of elements is preserved just like ArrayList.");

        // 1-2. add elements at the first or the last
        list.addFirst("0Aria");
        list.addLast("6Zoey");

        for (String s : list) {
            System.out.println(s);
        }
        System.out.println("added at the first and the last");
        System.out.println("----------------------------------------------------");
        System.out.println("LinkedList: the input order of elements is preserved.");
        System.out.println("----------------------------------------------------");

        // 2. Retrieve elements by index
        System.out.println("---------------------- 02:request by index-get");
        System.out.println(list.getFirst());
        System.out.println(list.get(1));
        System.out.println(list.getLast());
//        System.out.println(list.get("5Mia")); //wrong

        // 3. remove elements
        System.out.println("---------------------- 03-1:remove by value");
        System.out.println("before removal:------------- " + list.size()); // 7
        System.out.println("delete by value: 2Ben");
        list.remove("2Ben");                 //remove "2Ben"
        System.out.println("after removal:-------------- " + list.size()); // 6
        System.out.println(list.get(2));        //check the 3rd element

        System.out.println("---------------------- 03-2:remove by index");
        System.out.println("---------------------------------- the last");
        list.remove(list.size() - 1);     //remove the last element
        System.out.println("after removal of the last:---------- " + list.size()); // 5

        for (String s : list) {
            System.out.println(s);
        }

        // 3-2. remove elements at the first or the last
        list.removeFirst();
        list.removeLast();

        System.out.println("remove the elements at the first and the last");
        for (String s : list) {
            System.out.println(s);
        }

        // 4. replace elements: by value or by index
        System.out.println("---------------------- 04:replace-set");
        System.out.println(list.get(0) + " ---> " + "00Nora");
        System.out.println("before replacement: " + list.getFirst());
        list.set(0, "00Nora");      //replace the first element
        System.out.println("after replacement: " + list.getFirst());

        // 5. search: by index or by value
        System.out.println("---------------------- 05-1:search-indexOf");
        System.out.println("Where is 2Ben?");
        System.out.println(list.indexOf("2Ben"));

        System.out.println("---------------------- 05-2:search-contains");
        System.out.println("Is he in the list?");
        if (list.contains("2Ben")) {
            System.out.println("Yes!");
        } else {
            System.out.println("No");
        }

        // 6. remove all
        System.out.println("---------------------- 06:remove all-clear");
        list.clear();
        if (list.isEmpty()) {
            System.out.println("# of students: " + list.size());
            System.out.println("It is empty.");
        }

        System.out.println("------------------- new roster");
        list.add("Emma");
        list.add("Ben");
        list.add("Ava");
        list.add("Henry");
        list.add("Mia");
        list.add(2,"Ben"); //
        list.addFirst("Aria");
        list.addLast("Zoey");
        list.addLast("Zoey");  //
        list.addLast("Zoey");  //

        for (String s : list) {
            System.out.println(s);
        }

        // 7. iterator
        System.out.println("---------------------- 07:iterator");
        Iterator<String> iter = list.iterator();

        while(iter.hasNext()){
            String s = iter.next();
            System.out.println(s);
        }

        // 8. sort elements
        System.out.println("---------------------- 08:sort");
        Collections.sort(list);

        for (String s : list) {
            System.out.println(s);
        }
        System.out.println("------------------- sorted");
        System.out.println("-----------------------------------------------------");
        System.out.println("LinkedList is a resizable dynamic doubly-linked list with ordered elements, index-based access*, and allows duplicates.");
        System.out.println("           suitable for frequent insertion/deletion operations and less frequent element access");
        System.out.println("-----------------------------------------------------");
            }
}
