package Generics;

//=======================================
//        HashMap + LinkedHashMap
//=======================================
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
public class Gradebook {
    public static void main(String[] args) {
        //============================================================
        // Collections Framework ( List, [Map], Set)
        //============================================================
        System.out.println("--- HashMap (Key, Value) ---");
        System.out.println("---------------------- 01:HashMap-put");
        HashMap<String, Integer> hmap = new HashMap<>();

        // 1. add elements-put
        hmap.put("1Emma",100);
        hmap.put("2Ben",200);
        hmap.put("3Ava",300);
        hmap.put("4Henry",400);
        hmap.put("5Mia",500);

        // 2. iterate Keys
        System.out.println("---------- 02-1:Keys iterated-keySet");
        for (String key : hmap.keySet()) {
            System.out.println(key);
        }

        System.out.println("---------- 02-2:Values iterated-values");
        for (int value : hmap.values()) {
            System.out.println(value);
        }

        System.out.println("---------- 02-3:Keys & Values iterated-keySet, get");
        for (String key : hmap.keySet()) {
            //System.out.println(key +"\t"+ hmap.values());
            System.out.println(key +"\t"+ hmap.get(key));
        }

        System.out.println("---------------------------------------------------------------------");
        System.out.println("HashMap: the input order of elements is NOT preserved.");
        System.out.println("---------------------------------------------------------------------");

        // no duplicate
        System.out.println("# of students before adding key duplicates: " + hmap.size());
        hmap.put("2Ben",200);
        hmap.put("2Ben",300);
        hmap.put("2Ben",500); // only the last input value will be updated

        for (String key : hmap.keySet()) {
            System.out.println(key +"\t"+ hmap.get(key));
        }
        System.out.println("# of students after adding key duplicates: " + hmap.size());
        System.out.println("---------------------------------------------------------------------");
        System.out.println("HashMap does not allow key duplicates.");
        System.out.println("---------------------------------------------------------------------");

        // 3. request values
        System.out.println("---------------------- 03:request values using Keys-get(key)");
        System.out.println("1Emma's points: "+ hmap.get("1Emma"));
        System.out.println("3Ava's points: "+hmap.get("3Ava"));

        // 4. remove elements
        System.out.println("---------------------- 03-1:remove by keys");
        System.out.println("delete by key: 4Henry");
        hmap.remove("4Henry");                 //remove "4Henry"
        System.out.println(hmap.get("4Henry"));    //check

        for (String key : hmap.keySet()) {
            System.out.println(key +"\t"+ hmap.get(key));
        }

        // 5. replace elements: by value or by index
        System.out.println("---------------------- 05-1:replace the value for a key-replace");
        System.out.println("3Ava's 300 ---> 900");
        hmap.replace("3Ava", 900);

        for (String key : hmap.keySet()) {
            System.out.println(key +"\t"+ hmap.get(key));
        }

        System.out.println("---------------------- 05-2:replace a key only-put");
        System.out.println("1Emma ---> 6Ivy");
        hmap.put("6Ivy", hmap.remove("1Emma"));

        for (String key : hmap.keySet()) {
            System.out.println(key +"\t"+ hmap.get(key));
        }

        // 6. search: by index or by value
        System.out.println("---------------------- 06-2:search keys-contains");
        System.out.println("Is 6Ivy in the list?");
        if (hmap.containsKey("6Ivy")) {
            System.out.println("Yes!");

            // update the grade
            int point = hmap.get("6Ivy");
            hmap.put("6Ivy",point+700);
        } else {
            System.out.println("No");
        }

        System.out.println(hmap); // {key=value, ... }

        // 7. iterator
        System.out.println("---------------------- 07:iterator");
        Iterator<String> iter = hmap.keySet().iterator();

        while(iter.hasNext()){
            String s = iter.next();
            System.out.println(s);
        }

        // 8. remove all
        System.out.println("---------------------- 08:remove all-clear");
        hmap.clear();
        if (hmap.isEmpty()) {
            System.out.println("# of students: " + hmap.size());
        }

        System.out.println("------------------- new gradebook");
        hmap.put("5Mia",500);
        hmap.put("4Henry",400);
        hmap.put("3Ava",300);
        hmap.put("2Ben",200);
        hmap.put("1Emma",100);

        for (String key : hmap.keySet()) {
            System.out.println(key + "\t" + hmap.get(key));
        }

        System.out.println("---------------------------------------------------------------------");
        System.out.println("HashMap: resizable, unordered collection of key-value pairs and uniqueness of its Keys.");
        System.out.println("---------------------------------------------------------------------");

        System.out.println("---------------------- 08:LinkedHashMap-put");
        LinkedHashMap<String, Integer> lmap = new LinkedHashMap<>();
        lmap.put("5Mia",500);
        lmap.put("4Henry",400);
        lmap.put("3Ava",300);
        lmap.put("2Ben",200);
        lmap.put("1Emma",100);

        for (String key : lmap.keySet()) {
            System.out.println(key + "\t" + lmap.get(key));
        }

        System.out.println("---------------------------------------------------------------------");
        System.out.println("LinkedHashMap: resizable, 'ordered' input elements and uniqueness of its Keys.");
        System.out.println("               suitable for frequent lookups on large amounts of key-value pairs data.");
        System.out.println("---------------------------------------------------------------------");
    }
}
