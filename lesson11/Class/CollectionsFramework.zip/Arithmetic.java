package Generics;
//==============================================
// Stack: LIFO/FILO - box with a single opening
//==============================================
import java.util.Stack;

public class Arithmetic {
    public static void main(String[] args) {
        System.out.println("---------------------- 01:Stack-push");
        Stack<String> stack = new Stack<>();

        // 1. Add elements
        //"(3+2)x3-3"
        stack.push("(");
        stack.push("2");
        stack.push("+");
        stack.push("3");
        stack.push(")");
        stack.push("x");
        stack.push("3");
        stack.push("-");
        stack.push("3");

        // Print all elements
        System.out.println(stack); // [value, ...]
        System.out.println(" 1, 2, 3, 4, 5, 6, 7, 8, 9 ---> input order: Stack preserves the input order of elements.");
        System.out.println(stack + "---> out");
        System.out.println("bottom,                \"top\": the last-in sits on the top of the stack (LIFO)");

        System.out.println("---------------------------------------------------------------------");
        System.out.println("Stack (LIFO): resizable, ordered input elements, duplicates.");
        System.out.println("---------------------------------------------------------------------");

//        // iterate elements
//        for (String s : stack) {
//            System.out.println(s);
//        }

        // 2. Retrieve
        System.out.println("---------------------- 02:Retrieve the top-peek");
        System.out.println("retrieve the top: " + stack.peek());

        // 3. Remove
        System.out.println("---------------------- 03:Remove the top-pop");
        System.out.println("before pop(): " + stack);
        System.out.println("----------------------------------------- size: " + stack.size());
        System.out.println("remove the top: " + stack.pop());
        System.out.println("after pop(): " + stack);
        System.out.println("----------------------------------------- size: " + stack.size());

        // 4. Search
        System.out.println("---------------------- 04-1:Search-contains");
        System.out.println("the stack contains 3: " + stack.contains("3"));
        System.out.println("---------------------- 04-2:Search-how far is it from the top");
        String target = "3";
        //String target = "x";
        System.out.println(stack);
        System.out.println("----------------3, 2, 1");
        System.out.println("Where is " + target + " from the top? " + stack.search(target));
        System.out.println("the first occurrence of " + target + " is at position " + stack.search(target) + " from the top.");
        System.out.println("the position returned by the search() method is 1-based, " + "\n" +
                "meaning that the top element of the stack has a position of 1.");

        System.out.println("---------------------- (search-indexOf)");
        System.out.println("Where is 3?");
        System.out.println(stack.indexOf("3") + " " +
                "(index)");
        System.out.println("------------------------------------------------------");
        System.out.println("stack is not primarily designed for index-based access.");
        System.out.println("------------------------------------------------------");

        // 6. remove all
        System.out.println("---------------------- 06:remove all-clear");
        stack.clear();
        System.out.println("Is the stack empty? " + stack.isEmpty());
        System.out.println("after clear(): " + stack);

        System.out.println("---------------------------------------------------------------------");
        System.out.println("Stack is resizable, preserves input order of elements and allows duplicates.");
        System.out.println("         mainly designed for LIFO operations on the top element.");
        System.out.println("---------------------------------------------------------------------");
    }
}
