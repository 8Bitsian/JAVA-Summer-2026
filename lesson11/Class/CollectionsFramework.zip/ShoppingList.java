package Generics;

//=======================================
//        HashSet + LinkedHashSet
//=======================================
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;


public class ShoppingList {
    public static void main(String[] args) {
        //============================================================
        // Collections Framework ( List, Map, [Set])
        //============================================================
        System.out.println("---------------------- 01:HashSet-add");
        HashSet<String> set = new HashSet<>();

        // 1. add elements
        set.add("cake flour");
        set.add("baking powder");
        set.add("sea salt");
        set.add("castor sugar");
        set.add("milk");
        set.add("melted butter");
        set.add("egg");
        set.add("red bean paste");
        set.add("red bean paste");//
        set.add("red bean paste");//
        // iterate elements
        for (String s : set) {
            System.out.println(s);
        }
        System.out.println("------------ 10 items added");
        System.out.println("# of items: ---------------- " + set.size());

        System.out.println("----------------------------------------------------");
        System.out.println("HashSet does not allow any duplicates.");
        System.out.println("       : the input order of elements is NOT preserved.");
        System.out.println("----------------------------------------------------");

        // 2. remove elements
        System.out.println("---------------------- 03:remove");
        System.out.println("before removal:------------- " + set.size()); // 8
        System.out.println("delete by value: egg");
        set.remove("egg");                 //remove "egg"
        System.out.println("after removal:-------------- " + set.size()); // 7
        for (String s : set) {
            System.out.println(s);
        }

        // 3. search by value
        System.out.println("---------------------- 03:search-contains");
        System.out.println("Find \"egg\"");
        if (set.contains("egg")) {
            System.out.println("Yes!");
        } else {
            System.out.println("No");
        }

        // 4. iterator
        System.out.println("---------------------- 04:iterator");
        Iterator<String> iter = set.iterator();

        while(iter.hasNext()){
            String s = iter.next();
            System.out.println(s);
        }

        // 5. remove all
        System.out.println("---------------------- 05:remove all-clear");
        set.clear();
        if (set.isEmpty()) {
            System.out.println("# of items: " + set.size());
            System.out.println("It is empty.");
        }

        System.out.println("------------------- new HashSet");
        HashSet<Integer> iset = new HashSet<>();
        iset.add(1);
        iset.add(5);
        iset.add(2);
        iset.add(3);
        iset.add(5);
        for (int i: iset) {
            System.out.println(i);
        }

        System.out.println("-----------------------------------------------------");
        System.out.println("HashSet: resizable, unordered elements, uniqueness in its elements (no duplicates).");
        System.out.println("         suitable when you need to keep track of a set of unique elements.");
        System.out.println("-----------------------------------------------------");

        // 6. LinkedHashSet
        System.out.println("---------------------- 06:LinkedHashSet");
        LinkedHashSet<Integer> lset = new LinkedHashSet<>();
        lset.add(1);
        lset.add(5);
        lset.add(2);
        lset.add(3);
        lset.add(5);
        for (int i: lset) {
            System.out.println(i);
        }

        System.out.println("-----------------------------------------------------");
        System.out.println("LinkedHashSet: resizable, 'ordered' elements, uniqueness in its elements (no duplicates).");
        System.out.println("          suitable when you need both uniqueness and a consistent order of elements");
        System.out.println("-----------------------------------------------------");

    }
}
