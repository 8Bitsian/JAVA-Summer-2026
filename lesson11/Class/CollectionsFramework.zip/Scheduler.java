package Generics;
//=============================================
// Priority Queue:
// ============================================
import java.util.PriorityQueue;
import java.util.Comparator;
public class Scheduler {
    public static void main(String[] args) {
        System.out.println("-----------------------------------------------------------");
        System.out.println("PriorityQueue orders elements based on their priority. " );
        System.out.println("1. natural order (default): ascending/lexicographical order");
        System.out.println("2. custom order defined by a comparator");
        System.out.println("-----------------------------------------------------------");

//        System.out.println("====================================== I. ascending order");
//        PriorityQueue<String> queue = new PriorityQueue<>();

        System.out.println("====================================== II. descending order");
        //PriorityQueue<String> queue = new PriorityQueue<>(Comparator.reverseOrder());
        PriorityQueue<Integer> queue = new PriorityQueue<>(Comparator.reverseOrder());


//        System.out.println("====================================== III. custom order");
//        // Custom comparator based on string length
//        Comparator<String> customComparator = (s1, s2) -> Integer.compare(s1.length(), s2.length());
//        PriorityQueue<String> queue = new PriorityQueue<>(customComparator);

        System.out.println("---------------------- 01:PriorityQueue-add & offer");
        // 1. Add elements
//        queue.add("#1-gym");
//        queue.add("#2-coding");
//        queue.offer("#3-meal");
//        queue.offer("#2-coding");
//        queue.offer("#5-meditation");
//        queue.offer("#6-cleaning");

//        queue.add("A");
//        queue.add("B");
//        queue.offer("C");
//        //queue.offer("C");
//        queue.offer("D");
//        queue.offer("E");

        queue.add(1);
        queue.add(2);
        queue.add(3);
//        queue.add(3);
        queue.add(5);
        queue.add(6);
        //queue.offer(3);
//        queue.offer(4);
//        queue.offer(5);

        // Print all elements
        System.out.println(queue);
//        System.out.println("   1,      2,      3,      4,      5,      6,");
        System.out.println("out <---" + queue);
        System.out.println("        \"front\" ----------------------------------------------- rear : First-In-First-Out (FIFO)");

        System.out.println("---------------------------------------------------------------------");
        System.out.println("PriorityQueue: resizable, ordered based on priority, duplicates.");
        System.out.println("---------------------------------------------------------------------");

        // 2. Retrieve
        System.out.println("---------------------- 02:Retrieve the front-element & peek");
        System.out.println("element() :" + queue.element() + " or throws \'NoSuchElementException\'");
        System.out.println("peek() :" + queue.peek() + " or returns \'null\'");

        // 3. Remove
        System.out.println("---------------------- 03:Remove the head-remove & poll");
        System.out.println("before remove(): " + queue);
        System.out.println("                  \"front\" --------------------------------------------- rear");
        System.out.println("----------------- size: " + queue.size());

        System.out.println("remove(): " + queue.remove() + " removed, or \'NoSuchElementException\'");
        System.out.println("after remove(): " + queue);
        System.out.println("---------------- size: " + queue.size());

        System.out.println(queue.poll() + " polled.");
        System.out.println("poll(): " + queue.poll() + " polled, or returns \'null\'");
        System.out.println("---------------- size: " + queue.size());

        // 4. Search
        System.out.println("---------------------- 04-1:Search-contains");
        System.out.println("the priorityQueue contain pdf1: " + queue.contains("pdf1"));

        System.out.println("------------------------------------------------------");
        System.out.println("priorityQueue does not allow random access to its elements.");
        System.out.println("      is not for index-based access.");
        System.out.println("------------------------------------------------------");

        // 5. remove all
        System.out.println("---------------------- 05:remove all-clear");
        queue.clear();
        System.out.println("Is the priorityQueue empty? " + queue.isEmpty());
        System.out.println("after clear(): " + queue);

        System.out.println("---------------------------------------------------------------------");
        System.out.println("PriorityQueue is resizable, orders elements based on priority, and allows duplicates.");
        System.out.println("          mainly designed for efficient removal of the highest-priority element.");
        System.out.println("---------------------------------------------------------------------");
    }
}
