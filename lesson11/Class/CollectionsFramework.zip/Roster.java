package Generics;

//=======================================
//        ArrayList
//=======================================
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Roster {
    public static void main(String[] args) {
        //Array: store & print out element- 1Emma,2Ben, 3Ave
        String[] arr   = new String[4];
        arr[0] = "1Emma";
        arr[1] = "2Ben";
        arr[2] = "3Ava";
        arr[3] = "3Ava"; // duplicate

        //print all the elements
        System.out.println("---------------------- 00:Array");
        for (String s : arr) {
            System.out.println(s);
        }

        System.out.println("-----------------------------------------------------");
        System.out.println("Array is a fixed-size list with ordered elements, index-based access, and allows duplicates.");
        System.out.println("-----------------------------------------------------");

        //============================================================
        // Collections Framework ( [List], Map, Set)
        //============================================================
        System.out.println("---------------------- 01:ArrayList-add");
        ArrayList<String> alist = new ArrayList<>();
        //ArrayList<String> alist = new ArrayList<String>();

        // 1. add elements
        alist.add("1Emma");
        alist.add("2Ben");
        alist.add("3Ava");
        alist.add("5Mia");
        alist.add("5Mia"); // duplicate
        alist.add(3,"4Henry"); //inserts an element at a specific index

        //print all the elements
        for (String s : alist) {
            System.out.println(s);
        }//check input order

        System.out.println("----------------------------------------------------");
        System.out.println("ArrayList: the input order of elements is preserved, duplicates are allowed.");
        System.out.println("----------------------------------------------------");

        // 2. request elements by index
        System.out.println("---------------------- 02:request by index-get");
        System.out.println("the second element: " + alist.get(1));
//        System.out.println(alist.get("5Mia")); //wrong

        // 3. remove elements
        System.out.println("---------------------- 03-1:remove by value");
        System.out.println("before removal:------------- " + alist.size()); // 5
        System.out.println("delete by value: "+ alist.get(1));
        alist.remove("5Mia");                //remove
        System.out.println("after removal:-------------- " + alist.size()); // 4
        System.out.println(alist);

        System.out.println("---------------------- 03-2:remove by index");
        System.out.println("---------------------------------- the last");
        alist.remove(alist.size() - 1);   //remove the last element remove
        System.out.println("after removal of the last:---------- " + alist.size()); // 3

        for (String s : alist) {
            System.out.println(s);
        }

        // 4. replace elements
        System.out.println("---------------------- 04:replace-set");
        System.out.println(alist.get(0) + " ---> " + "00Nora");
        System.out.println("before replacement: " + alist.get(0));
        alist.set(0, "00Nora");         //replace the first element
        System.out.println("after replacement: " + alist.get(0));

        // 5. search: by index or by value
        System.out.println("---------------------- 05-1:search-indexOf");
        System.out.println("Where is 2Ben?");
        System.out.println(alist.indexOf("2Ben"));  //indexOf

        System.out.println("---------------------- 05-2:search-contains");
        System.out.println("Is he in the list?");
        if (alist.contains("2Ben")) {               //contains
            System.out.println("Yes!");
        } else {
            System.out.println("No");
        }

        // 6. remove all
        System.out.println("---------------------- 06:remove all-clear");
        alist.clear();
        if (alist.isEmpty()) {
            System.out.println("# of students: " + alist.size());
            System.out.println("It is empty.");
        }

        System.out.println("------------------- new roster");
        alist.add("Mia");
        alist.add("Ben");
        alist.add("Ava");
        alist.add("Henry");
        alist.add("Emma");
        alist.add("Emma");  //
        alist.add("Mia");   //
        alist.add("Emma");  //

        for (String s : alist) {
            System.out.println(s);
        }

        // 7. iterator
        System.out.println("---------------------- 07:iterator");
        Iterator<String> iter = alist.iterator();

        while(iter.hasNext()){
            String s = iter.next();
            System.out.println(s);
        }

        // 8. sort elements
        System.out.println("---------------------- 08:sort");
        Collections.sort(alist);

        for (String s : alist) {
            System.out.println(s);
        }
        System.out.println("------------------- sorted");

        System.out.println("-----------------------------------------------------");
        System.out.println("ArrayList is a resizable dynamic array with ordered elements, index-based access, and allows duplicates.");
        System.out.println("          suitable for frequent element access and less frequent insertion/deletion operations");
        System.out.println("-----------------------------------------------------");




    }
}




