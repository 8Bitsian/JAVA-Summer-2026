package Generics;
//=============================================
// Queue: FIFO/LILO - box with double openings
// ============================================
import java.util.LinkedList;
import java.util.Queue;
public class PrintSpooler {
    public static void main(String[] args) {
        System.out.println("---------------------- 01:Queue-add & offer");
        //Queue<String> queue = new Queue<>(); //Queue is abstract, which cannot be instantiated
        Queue<String> queue = new LinkedList<>();

        // 1. Add elements
        queue.add("doc1");
        queue.add("doc2");
        queue.offer("pdf1");
        queue.offer("pdf2");
        queue.offer("pdf1");
        queue.offer("doc3");

        // Print all elements
        System.out.println(queue); // [value, ...]
        System.out.println("  1,    2,    3,    4,    5,    6,  : Queue preserves the input order of elements.");
        System.out.println("out <---" + queue);
        System.out.println("        \"front\" ---------------------- rear : First-In-First-Out (FIFO)");

        System.out.println("---------------------------------------------------------------------");
        System.out.println("Queue (FIFO): resizable, ordered input elements, duplicates.");
        System.out.println("---------------------------------------------------------------------");

        // 2. Retrieve
        System.out.println("---------------------- 02:Retrieve the front-element & peek");
        System.out.println("element() :"+ queue.element() + " or throws \'NoSuchElementException\'");
        System.out.println("peek() :" + queue.peek() + " or returns \'null\'");

        // 3. Remove
        System.out.println("---------------------- 03:Remove the head-remove & poll");
        System.out.println("before remove(): " + queue);
        System.out.println("                 \"front\" ---------------------- rear");
        System.out.println("----------------- size: " + queue.size());

        System.out.println("remove(): " + queue.remove() + " removed, or \'NoSuchElementException\'");
        System.out.println("after remove(): " + queue);
        System.out.println("                \"front\" --------------- rear");
        System.out.println("---------------- size: " + queue.size());

        System.out.println("poll(): " + queue.poll() + " polled, or returns \'null\'");
        System.out.println("after poll(): " + queue);
        System.out.println("               \"front\" ---------- rear");
        System.out.println("---------------- size: " + queue.size());

        // 4. Search
        System.out.println("---------------------- 04-1:Search-contains");
        System.out.println("the queue contains pdf1: " + queue.contains("pdf1"));

        System.out.println("------------------------------------------------------");
        System.out.println("queue does not allow random access to its elements.");
        System.out.println("      is not for index-based access.");
        System.out.println("------------------------------------------------------");

        // 5. remove all
        System.out.println("---------------------- 05:remove all-clear");
        queue.clear();
        System.out.println("Is the queue empty? " + queue.isEmpty());
        System.out.println("after clear(): " + queue);

        System.out.println("---------------------------------------------------------------------");
        System.out.println("Queue is resizable, preserves input order of elements and allows duplicates.");
        System.out.println("         mainly designed for FIFO operations on the front element.");
        System.out.println("---------------------------------------------------------------------");
    }
}
